﻿namespace CinemaWebApp.ViewModels
{
    public class MovieProgramViewModel
    {
        public string Title { get; set; } = null!;
        public int Duration { get; set; }
    }
}
